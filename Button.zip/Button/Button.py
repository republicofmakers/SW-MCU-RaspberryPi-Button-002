from machine import Pin
import time

led = Pin(27, Pin.OUT)
button = Pin(28, Pin.IN)  # No internal pull; you use external pull-down resistor

while True:
    if button.value() == 1:  # Button pressed (pulled high)
        led.on()
    else:
        led.off()
    time.sleep(0.01)  # Debounce delay